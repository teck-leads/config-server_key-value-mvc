package com.fresco.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class KeyStoreService {
	@Autowired
	private KeyRepository keyRepository;

	public KeyStore saveKeyStore(KeyStore keyStore) {
		removeComma(keyStore);
		
		
		if (StringUtils.isEmpty(keyStore.getKeyIndex()) && !StringUtils.isEmpty(keyStore.getKey())) {
			// save
			KeyStore save = keyRepository.save(keyStore);
			Integer id = save.getId();
			save.setKeyIndex(id);
			keyRepository.save(keyStore);

			return save;
		} else if (!StringUtils.isEmpty(keyStore.getKeyIndex()) && !StringUtils.isEmpty(keyStore.getKey())) {
			// update
			Optional<KeyStore> findByKey = keyRepository.findByKey(keyStore.getKey());

			KeyStore keyStore2 = findByKey.get();
			keyStore2.setKeyIndex(keyStore.getKeyIndex());
			KeyStore save = keyRepository.save(keyStore2);
			
			
			if(keyRepository.findById(keyStore.getKeyIndex()+1).isPresent()) {
				KeyStore keyStore3 = keyRepository.findById(keyStore.getKeyIndex()+1).get();
				keyStore3.setKey(keyStore2.getKey());
				keyRepository.save(keyStore3);
			}
			
			return save;
		} else if (!StringUtils.isEmpty(keyStore.getKeyIndex()) && StringUtils.isEmpty(keyStore.getKey())) {
			//deleteByIndex(keyStore.getKeyIndex());
			deleteByIndex(2);
			return  null;
		}else {
			throw new RuntimeException("please enter value");
		}

		

	}

	public List<KeyStore> findAll() {
		List<KeyStore> findAll = keyRepository.findAll();

		findAll.forEach(key -> {
			removeComma(key);
		});
		return findAll;

	}

	public void deleteByIndex(Integer id) {

		Optional<KeyStore> findByKeyIndex = keyRepository.findByKeyIndex(id);

		if (findByKeyIndex.isPresent()) {
			KeyStore keyStore = findByKeyIndex.get();
			Integer id2 = keyStore.getId();
			keyRepository.deleteById(id2);
		}
	}
	
	
	public Optional<KeyStore> findByIndex(Integer id) {

		return  keyRepository.findByKeyIndex(id);

		
	}
	

	public void removeComma(KeyStore keyStore) {
		if (!StringUtils.isEmpty(keyStore.getKey())) {
			String key = keyStore.getKey().replaceAll(",", "");
			keyStore.setKey(key);
		}
	}
	
	public void deleteAll() {
		keyRepository.deleteAll();	
	}

}
