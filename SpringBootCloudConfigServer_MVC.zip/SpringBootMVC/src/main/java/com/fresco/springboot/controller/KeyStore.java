package com.fresco.springboot.controller;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

@Entity
@SequenceGenerator(name = "key_store_seq", initialValue = 1, allocationSize = 1)
public class KeyStore implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * 
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "key_store_seq")
	private Integer id;
	private String key;
	private Integer keyIndex;
	@Transient
	private String form1;
	@Transient
	private String form2;
	@Transient
	private String form3;
	
	

	public String getForm1() {
		return form1;
	}

	public void setForm1(String form1) {
		this.form1 = form1;
	}

	public String getForm2() {
		return form2;
	}

	public void setForm2(String form2) {
		this.form2 = form2;
	}

	public String getForm3() {
		return form3;
	}

	public void setForm3(String form3) {
		this.form3 = form3;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Integer getKeyIndex() {
		return keyIndex;
	}

	public void setKeyIndex(Integer keyIndex) {
		this.keyIndex = keyIndex;
	}

	

	public KeyStore() {
		
	}

	@Override
	public String toString() {
		return "KeyStore [id=" + id + ", key=" + key + ", keyIndex=" + keyIndex + ", form1=" + form1 + ", form2="
				+ form2 + ", form3=" + form3 + "]";
	}
	
	
	
	

}
