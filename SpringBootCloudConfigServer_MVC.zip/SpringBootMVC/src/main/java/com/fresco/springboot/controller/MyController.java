package com.fresco.springboot.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MyController {

	@Autowired
	private KeyStoreService keyStoreService;


	@GetMapping(value = { "/" })
	public String registrationPage(@ModelAttribute("keyStore") KeyStore keyStore, Model model) {

		List<KeyStore> findAll = keyStoreService.findAll();
		
		List<String> keyStores=new ArrayList<>();
		findAll.forEach(keys->{
			
			keyStores.add(String.valueOf(keys.getKey()));
		});
		
		model.addAttribute("keyStores", findAll);
		model.addAttribute("keyStores1", keyStores);

		return "register";
	}

	@PostMapping(value = { "/" })
	public String saveUser(@ModelAttribute("keyStore") KeyStore keyStore, Model model) {
		removeComma(keyStore);
		if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm1()) && org.springframework.util.StringUtils.isEmpty(keyStore.getKey())) {
			List<KeyStore> findAll = keyStoreService.findAll();
			model.addAttribute("keyStores", findAll);
			model.addAttribute("errorMsg", "please enter some input");
			return "register";
		} else if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm2())
				&& (org.springframework.util.StringUtils.isEmpty(keyStore.getKeyIndex()) || org.springframework.util.StringUtils.isEmpty(keyStore.getKey()))) {
			List<KeyStore> findAll = keyStoreService.findAll();
			model.addAttribute("keyStores", findAll);
			model.addAttribute("errorMsg", "please enter some input");
			return "register";
		} else if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm3()) && (org.springframework.util.StringUtils.isEmpty(keyStore.getKeyIndex()))) {
			List<KeyStore> findAll = keyStoreService.findAll();
			model.addAttribute("keyStores", findAll);
			model.addAttribute("errorMsg", "please enter some input");
			return "register";
		} else if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm3()) && (!org.springframework.util.StringUtils.isEmpty(keyStore.getKeyIndex()) && keyStoreService.findByIndex(keyStore.getKeyIndex()).isEmpty())) {
			
			List<KeyStore> findAll = keyStoreService.findAll();
			model.addAttribute("keyStores", findAll);
			model.addAttribute("errorMsg", "index not found");
			return "register";
		}
		
		else {
			//keyStoreService.deleteAll();
			keyStoreService.saveKeyStore(keyStore);
			return "redirect:/";
			
		}

	//	return "redirect:/";
	}
	
	public void removeComma(KeyStore keyStore) {
		if (!org.springframework.util.StringUtils.isEmpty(keyStore.getKey())) {
			String key = keyStore.getKey().replaceAll(",", "");
			keyStore.setKey(key);
		}
		if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm1())) {
			String form = keyStore.getForm1().replaceAll(",", "");
			keyStore.setForm1(form);
		}
		if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm2())) {
			String form = keyStore.getForm2().replaceAll(",", "");
			keyStore.setForm2(form);
		}
		if (!org.springframework.util.StringUtils.isEmpty(keyStore.getForm3())) {
			String form = keyStore.getForm3().replaceAll(",", "");
			keyStore.setForm3(form);
		}
	}

}