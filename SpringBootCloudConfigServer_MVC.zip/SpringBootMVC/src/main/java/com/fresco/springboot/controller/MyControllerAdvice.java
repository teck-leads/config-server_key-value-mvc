package com.fresco.springboot.controller;

public class MyControllerAdvice {
}