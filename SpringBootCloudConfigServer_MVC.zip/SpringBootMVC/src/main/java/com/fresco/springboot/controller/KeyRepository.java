package com.fresco.springboot.controller;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface KeyRepository extends JpaRepository<KeyStore, Integer> {
	
	Optional<KeyStore> findByKey(String key);
	Optional<KeyStore> findByKeyIndex(Integer keyIndex);
	
	

}
