package com.fresco.cloudconfig;

import static org.junit.Assert.assertEquals;

import org.json.JSONObject;
import org.junit.FixMethodOrder;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
class SpringBootCloudConfigServerApplicationTests {
	@LocalServerPort
	int port;
	@Value("${spring.cloud.config.server.git.uri}")
	private String gitUri;
	@Autowired
	TestRestTemplate restTemplate;

	@Test
	void test0() {
		try {
			gitUri = gitUri.replace("github.com", "raw.githubusercontent.com") + "/master/config-client.properties";
			String content = restTemplate.getForObject(gitUri, String.class);
			assertEquals("server.port=8000", content.trim());
		} catch (Exception e) {
			e.printStackTrace();
			assert (false);
		}
	}

	@Test
	void test1() {
		try {
			String content = restTemplate.getForObject("http://localhost:" + port + "/config-client/master/",
					String.class);
			JSONObject json = new JSONObject(content);
			json = (JSONObject) json.getJSONArray("propertySources").get(0);
			assertEquals(gitUri + "/config-client.properties", json.getString("name"));
			assertEquals("8000", json.getJSONObject("source").getJSONObject("server.port").getString("value"));
		} catch (Exception e) {
			e.printStackTrace();
			assert (false);
		}
	}
}
